var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/functions/basicAuthorizer/handler.ts
var handler_exports = {};
__export(handler_exports, {
  main: () => main
});
module.exports = __toCommonJS(handler_exports);

// src/services/auth.ts
var decodeAuthString = (authString) => {
  try {
    const [user, password] = Buffer.from(authString.split(" ")[1], "base64").toString().split(":");
    return { user, password };
  } catch (e) {
    return { user: "", password: "" };
  }
};
var getDBUser = () => {
  try {
    const [userCreds, passwordCreds] = process.env.AUTH_USER.split("=");
    return { userCreds, passwordCreds };
  } catch (e) {
    return { userCreds: "", passwordCreds: "" };
  }
};
var isValidUser = (credentials) => {
  const { user, password } = decodeAuthString(credentials);
  const { userCreds, passwordCreds } = getDBUser();
  return userCreds === user && passwordCreds === password;
};
var generateResponse = (principalId, effect, methodArn) => {
  return {
    principalId,
    policyDocument: {
      Version: "2012-10-17",
      Statement: [
        {
          Action: "execute-api:Invoke",
          Effect: effect,
          Resource: methodArn
        }
      ]
    }
  };
};

// src/functions/basicAuthorizer/handler.ts
var main = async (event) => {
  const authHeader = event.headers.Authorization;
  console.log(JSON.stringify(event));
  const { methodArn } = event;
  const response = isValidUser(authHeader) ? generateResponse("testPrincipal", "Allow", methodArn) : generateResponse("testPrincipal", "Deny", methodArn);
  return response;
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  main
});
//# sourceMappingURL=handler.js.map
